import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RewardService {

  constructor() { }

  calculateRewardPoints(transactionAmount: number): number {
    let points = 0;
    
    
    if (transactionAmount > 100) {
      // A customer receives 2 points for every dollar spent over $100 in each transaction 
      points += 2 * (transactionAmount - 100);
    } else if (transactionAmount > 50) {
      // plus 1 point for every dollar spent over $50 in each transaction
      points += 1 * 50;
    }
    return points;
  }


}
