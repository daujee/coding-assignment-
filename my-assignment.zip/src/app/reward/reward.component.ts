import { Component, OnInit } from '@angular/core';
import { RewardService } from '../services/reward.service'
@Component({
  selector: 'app-reward',
  templateUrl: './reward.component.html',
  styleUrls: ['./reward.component.css']
})
export class RewardComponent implements OnInit {
    
  transactions: any = {
    
    "January": [120, 80, 150],
    "February": [100, 120, 150],
    "March": [150, 170, 200]
  };

  rewardsPerMonth: { [key: string]: number } = {};
  totalRewards: { [key: string]: number } = {};

  constructor(private rewardService: RewardService) { }


  ngOnInit(): void {
    this.calculateRewards();
  }

  
  calculateRewards(): void {
    for (const month in this.transactions) {
      if (this.transactions, month) {
        const amounts = this.transactions[month];
        const monthlyPoints = amounts.reduce((acc: any, amount: any) => acc + this.rewardService.calculateRewardPoints(amount), 0);
        this.rewardsPerMonth[month] = monthlyPoints;
        this.totalRewards[month] = Object.values(this.rewardsPerMonth).reduce((acc, val) => acc + val, 0);
      }
    }
  }

}
